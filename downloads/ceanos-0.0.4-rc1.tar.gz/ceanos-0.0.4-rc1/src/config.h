#ifndef __CONFIG__
#define __CONFIG__

//comment this line when you dont need debug mode
#define DEBUG

#endif