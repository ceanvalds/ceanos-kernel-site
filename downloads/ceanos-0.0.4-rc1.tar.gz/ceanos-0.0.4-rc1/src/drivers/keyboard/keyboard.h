void keyboard_init();
static void keyboardHandler(struct InterruptRegisters *regs);
void append(char *part);
