#pragma once

// syscalls
#define sys_write_code 0 

#define MAX_SYSCALLS 32 









