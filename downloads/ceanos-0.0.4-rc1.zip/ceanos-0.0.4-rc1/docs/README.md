# Welcome to the CeanOS Documentation

This directory contains everything you need to know about CeanOS (well, almost everything).