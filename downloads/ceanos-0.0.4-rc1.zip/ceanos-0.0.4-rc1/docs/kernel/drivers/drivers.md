# This file is just a list of all documented drivers of CeanOS

- VGA
- Keyboard
- PIT

## Needed

- ACPI
- PCI