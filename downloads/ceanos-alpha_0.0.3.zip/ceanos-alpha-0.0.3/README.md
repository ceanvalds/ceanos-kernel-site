![GitHub top language](https://img.shields.io/github/languages/top/asdasda3456/CeanOS)
![Contributors](https://img.shields.io/github/contributors/asdasda3456/CeanOS)
![Commits](https://img.shields.io/github/commit-activity/m/asdasda3456/CeanOS)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/asdasda3456/CeanOS)
![GitHub Release](https://img.shields.io/github/v/release/asdasda3456/CeanOS?include_prereleases)

## nothing to see here

![image](https://github.com/user-attachments/assets/af10190c-3ab3-4387-a117-94f61140416a)


