#ifndef SHELL_H
#define SHELL_H

#include "vga.h"
#include "stdint.h"

void run_term(); 

#endif // shell_h
